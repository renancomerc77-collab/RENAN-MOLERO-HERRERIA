import { useState } from 'react'
import { api } from './api'

export default function Login({ entrar }) {
  const [nome, setNome] = useState('')
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')
  const [cadastro, setCadastro] = useState(false)
  const [erro, setErro] = useState('')

  async function enviar(e) {
    e.preventDefault()
    try {
      const usuario = cadastro
        ? await api('/users', 'POST', { user_name: nome, user_email: email, user_password: senha })
        : await api('/login', 'POST', { user_email: email, user_password: senha })
      entrar(usuario)
    } catch (error) {
      setErro(error.message)
    }
  }

  return (
    <form className="login" onSubmit={enviar}>
      <h1>MOTTA</h1>
      <p>Peças e serviços para caminhões</p>

      {cadastro && (
        <label>
          Nome
          <input value={nome} onChange={(e) => setNome(e.target.value)} required />
        </label>
      )}
      <label>
        E-mail
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
      </label>
      <label>
        Senha
        <input type="password" value={senha} onChange={(e) => setSenha(e.target.value)} required />
      </label>

      {erro && <p className="aviso erro">{erro}</p>}

      <button className="btn azul">{cadastro ? 'Criar conta' : 'Entrar'}</button>
      <button type="button" className="link" onClick={() => { setCadastro(!cadastro); setErro('') }}>
        {cadastro ? 'Já tenho conta' : 'Criar uma conta'}
      </button>
    </form>
  )
}
