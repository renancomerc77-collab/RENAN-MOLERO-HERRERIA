import { useState, useEffect } from 'react'
import { api } from './api'
import Login from './Login'
import { paginas } from './telas'
import logo from './logo.jpg'

function Inicio({ irPara }) {
  const [totais, setTotais] = useState({})

  useEffect(() => {
    paginas.forEach((p) => {
      api('/' + p.id)
        .then((lista) => setTotais((t) => ({ ...t, [p.id]: lista.length })))
        .catch(console.error)
    })
  }, [])

  return (
    <section>
      <h1>Início</h1>
      <div className="resumo">
        {paginas.map((p) => (
          <button key={p.id} onClick={() => irPara(p.id)}>
            <strong>{totais[p.id] ?? '-'}</strong>
            {p.titulo}
          </button>
        ))}
      </div>
    </section>
  )
}

export default function App() {
  const [usuario, setUsuario] = useState(() => JSON.parse(localStorage.getItem('usuario')))
  const [pagina, setPagina] = useState('inicio')

  function entrar(dados) {
    localStorage.setItem('usuario', JSON.stringify(dados))
    setUsuario(dados)
  }

  function sair() {
    localStorage.removeItem('usuario')
    setUsuario(null)
  }

  if (!usuario) return <Login entrar={entrar} />

  const atual = paginas.find((p) => p.id === pagina)

  return (
    <>
      <nav>
        <img src={logo} alt="MOTTA" />
        {[{ id: 'inicio', titulo: 'Início' }, ...paginas].map((p) => (
          <button key={p.id} className={p.id === pagina ? 'ativo' : ''} onClick={() => setPagina(p.id)}>
            {p.titulo}
          </button>
        ))}
        <span>{usuario.user_email}</span>
        <button className="btn vermelho" onClick={sair}>Sair</button>
      </nav>
      <main>{atual ? <atual.Tela /> : <Inicio irPara={setPagina} />}</main>
    </>
  )
}
