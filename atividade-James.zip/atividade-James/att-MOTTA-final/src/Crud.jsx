import { useState, useEffect } from 'react'
import { api } from './api'

export function useLista(rota) {
  const [lista, setLista] = useState([])
  const carregar = () => api('/' + rota).then(setLista).catch(console.error)
  useEffect(() => { carregar() }, [rota])
  return [lista, carregar]
}

const opcao = (o) => (typeof o === 'object' ? o : { valor: o, rotulo: o })

function mostrar(c, valor) {
  if (c.moeda) return 'R$ ' + Number(valor || 0).toFixed(2).replace('.', ',')
  if (c.tipo === 'date') return valor.slice(0, 10).split('-').reverse().join('/')
  if (c.opcoes) return c.opcoes.map(opcao).find((o) => String(o.valor) === String(valor))?.rotulo ?? valor
  return valor
}

export default function Crud({ rota, pk, titulo, campos }) {
  const [lista, carregar] = useLista(rota)
  const [form, setForm] = useState({})
  const [idEdit, setIdEdit] = useState('')
  const [msg, setMsg] = useState('')

  function limpar() {
    setForm({})
    setIdEdit('')
  }

  async function tentar(acao, ok) {
    try {
      await acao()
      carregar()
      setMsg(ok)
    } catch (erro) {
      setMsg('Erro: ' + erro.message)
    }
    setTimeout(() => setMsg(''), 3000)
  }

  function salvar(e) {
    e.preventDefault()
    tentar(async () => {
      if (idEdit) await api(`/${rota}/${idEdit}`, 'PUT', form)
      else await api('/' + rota, 'POST', form)
      limpar()
    }, idEdit ? 'Registro atualizado.' : 'Registro cadastrado.')
  }

  function editar(item) {
    setForm(Object.fromEntries(campos.map((c) => {
      const valor = item[c.chave] ?? ''
      return [c.chave, c.tipo === 'date' ? valor.slice(0, 10) : valor]
    })))
    setIdEdit(item[pk])
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function excluir(id) {
    if (window.confirm('Excluir este registro?')) {
      tentar(() => api(`/${rota}/${id}`, 'DELETE'), 'Registro excluído.')
    }
  }

  return (
    <section>
      <h1>{titulo}</h1>
      {msg && <p className={msg.startsWith('Erro') ? 'aviso erro' : 'aviso'}>{msg}</p>}

      <form onSubmit={salvar}>
        <h3>{idEdit ? 'Editar registro' : 'Novo registro'}</h3>
        {campos.map((c) => {
          const props = {
            value: form[c.chave] ?? '',
            onChange: (e) => setForm({ ...form, [c.chave]: e.target.value }),
            required: true,
          }
          return (
            <label key={c.chave}>
              {c.rotulo}
              {c.opcoes ? (
                <select {...props}>
                  <option value="">Selecione</option>
                  {c.opcoes.map(opcao).map((o) => <option key={o.valor} value={o.valor}>{o.rotulo}</option>)}
                </select>
              ) : c.tipo === 'textarea' ? (
                <textarea {...props} required={false} maxLength={500} rows={3} />
              ) : (
                <input type={c.tipo} placeholder={c.dica} {...props}
                  {...(c.tipo === 'number' && { min: 0, step: 'any' })} />
              )}
            </label>
          )
        })}
        <button className="btn azul">{idEdit ? 'Salvar alterações' : 'Cadastrar'}</button>
        {idEdit && <button type="button" className="btn cinza" onClick={limpar}>Cancelar</button>}
      </form>

      {lista.length === 0 ? (
        <p className="vazio">Nenhum registro cadastrado.</p>
      ) : (
        <table>
          <thead>
            <tr>
              {campos.map((c) => <th key={c.chave}>{c.rotulo}</th>)}
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            {lista.map((item) => (
              <tr key={item[pk]}>
                {campos.map((c) => (
                  <td key={c.chave} data-label={c.rotulo}>{mostrar(c, item[c.chave])}</td>
                ))}
                <td>
                  <button className="btn azul pequeno" onClick={() => editar(item)}>Editar</button>
                  <button className="btn vermelho pequeno" onClick={() => excluir(item[pk])}>Excluir</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  )
}
