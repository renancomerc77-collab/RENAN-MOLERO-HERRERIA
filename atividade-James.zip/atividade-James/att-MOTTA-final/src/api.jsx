const URL = 'http://localhost:3333'

export async function api(rota, metodo = 'GET', corpo) {
  const resposta = await fetch(URL + rota, {
    method: metodo,
    headers: { 'Content-Type': 'application/json' },
    body: corpo && JSON.stringify(corpo),
  }).catch(() => {
    throw new Error('Não foi possível conectar na API.')
  })

  const dados = await resposta.json()
  if (!resposta.ok) throw new Error(dados.erro)
  return dados
}
