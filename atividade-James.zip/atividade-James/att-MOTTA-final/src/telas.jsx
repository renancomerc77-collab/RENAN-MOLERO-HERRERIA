import Crud, { useLista } from './Crud'

const tela = (id, pk, titulo, campos) => ({
  id,
  titulo,
  Tela: () => <Crud rota={id} pk={pk} titulo={titulo} campos={campos} />,
})

function Ordens() {
  const [clientes] = useLista('clientes')
  const [veiculos] = useLista('veiculos')

  return (
    <Crud rota="ordens" pk="ord_id" titulo="Ordens de serviço" campos={[
      { chave: 'cli_id', rotulo: 'Cliente', opcoes: clientes.map((c) => ({ valor: c.cli_id, rotulo: c.cli_nome })) },
      { chave: 'vei_id', rotulo: 'Placa', opcoes: veiculos.map((v) => ({ valor: v.vei_id, rotulo: v.vei_placa })) },
      { chave: 'ord_status', rotulo: 'Status', opcoes: ['Aberto', 'Em andamento', 'Concluído', 'Cancelado'] },
      { chave: 'ord_data', rotulo: 'Data', tipo: 'date' },
    ]} />
  )
}

export const paginas = [
  tela('clientes', 'cli_id', 'Clientes', [
    { chave: 'cli_nome', rotulo: 'Nome' },
    { chave: 'cli_email', rotulo: 'E-mail', tipo: 'email' },
    { chave: 'cli_telefone', rotulo: 'Telefone' },
    { chave: 'cli_cidade', rotulo: 'Cidade' },
  ]),
  tela('veiculos', 'vei_id', 'Veículos', [
    { chave: 'vei_marca', rotulo: 'Marca' },
    { chave: 'vei_modelo', rotulo: 'Modelo' },
    { chave: 'vei_ano', rotulo: 'Ano', tipo: 'number' },
    { chave: 'vei_placa', rotulo: 'Placa' },
  ]),
  tela('servicos', 'ser_id', 'Serviços', [
    { chave: 'ser_descricao', rotulo: 'Descrição' },
    { chave: 'ser_valor', rotulo: 'Valor (R$)', tipo: 'number', moeda: true },
    { chave: 'ser_duracao', rotulo: 'Duração', dica: 'Ex.: 2 horas' },
    { chave: 'ser_observacao', rotulo: 'Observação', tipo: 'textarea' },
  ]),
  tela('pecas', 'pec_id', 'Peças', [
    { chave: 'pec_nome', rotulo: 'Nome' },
    { chave: 'pec_numeracao', rotulo: 'Numeração' },
    { chave: 'pec_categoria', rotulo: 'Categoria', opcoes: ['Filtros', 'Freios', 'Suspensão', 'Pneus', 'Elétrica', 'Motor', 'Óleos', 'Mangueiras', 'Outros'] },
    { chave: 'pec_preco', rotulo: 'Preço (R$)', tipo: 'number', moeda: true },
    { chave: 'pec_quantidade', rotulo: 'Quantidade', tipo: 'number' },
  ]),
  { id: 'ordens', titulo: 'Ordens de serviço', Tela: Ordens },
]
