import cors from "cors";
import "dotenv/config";

import express from "express";
import { router } from "./routes";
import { tratarErros } from "./middlewares/erros";

const app = express();
app.use(express.json());

app.use(cors());
app.use(router);
app.use(tratarErros);

const PORT = process.env.PORT || 3333;

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
