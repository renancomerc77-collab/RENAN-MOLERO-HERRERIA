import { Request, Response, NextFunction } from "express";

export class ErroApi extends Error {
    status: number;

    constructor(mensagem: string, status = 400) {
        super(mensagem);
        this.status = status;
    }
}

export function tratarErros(erro: any, _req: Request, res: Response, _next: NextFunction) {
    if (erro instanceof ErroApi) {
        return res.status(erro.status).json({ erro: erro.message });
    }

    if (erro.code === "P2002") {
        return res.status(409).json({ erro: "Já existe um registro com esse valor!" });
    }
    if (erro.code === "P2003") {
        return res.status(409).json({ erro: "Registro ligado a outros dados ou referência inexistente!" });
    }
    if (erro.code === "P2025") {
        return res.status(404).json({ erro: "Registro não encontrado!" });
    }

    console.error(erro);
    return res.status(500).json({ erro: "Erro interno do servidor" });
}
