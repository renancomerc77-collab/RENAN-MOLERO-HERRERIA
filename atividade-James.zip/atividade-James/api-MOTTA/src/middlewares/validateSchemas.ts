import { Request, Response, NextFunction } from "express";
import { ZodError, ZodType } from "zod";

export const validateSchema =
(schema: ZodType) => async (req: Request, res: Response, next: NextFunction) => {

    try {
        const dados: any = await schema.parseAsync({
            body: req.body,
            query: req.query,
            params: req.params,
        })

        req.body = dados.body
        return next()
    } catch (error) {

        if(error instanceof ZodError){
            return res.status(400).json({
                erro: error.issues[0]?.message,
                detalhes: error.issues.map(issue => ({
                    campo: issue.path.slice(1).join('.'),
                    mensagem: issue.message
                }))
            })
        }

        return res.status(500).json({
            erro: "Erro interno do servidor",
        })

    }
}
