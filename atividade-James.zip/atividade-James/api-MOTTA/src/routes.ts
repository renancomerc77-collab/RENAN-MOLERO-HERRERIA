import { Router } from "express";
import { ZodType } from "zod";
import prisma from "./prisma";
import { crud } from "./controllers/crud";
import * as user from "./controllers/UserController";
import { validateSchema } from "./middlewares/validateSchemas";
import {
    loginSchema, createUserSchema, updateUserSchema,
    clienteSchema, veiculoSchema, servicoSchema, pecaSchema, ordemSchema,
} from "./schemas/schemas";

const router = Router();

router.post("/login", validateSchema(loginSchema), user.login);
router.get("/users", user.listar);
router.get("/users/:id", user.buscar);
router.post("/users", validateSchema(createUserSchema), user.criar);
router.put("/users/:id", validateSchema(updateUserSchema), user.atualizar);
router.delete("/users/:id", user.excluir);

function rotas(caminho: string, c: ReturnType<typeof crud>, schema: ZodType) {
    router.get(`/${caminho}`, c.listar);
    router.get(`/${caminho}/:id`, c.buscar);
    router.post(`/${caminho}`, validateSchema(schema), c.criar);
    router.put(`/${caminho}/:id`, validateSchema(schema), c.atualizar);
    router.delete(`/${caminho}/:id`, c.excluir);
}

rotas("clientes", crud(prisma.cliente, "cli_id"), clienteSchema);
rotas("veiculos", crud(prisma.veiculo, "vei_id"), veiculoSchema);
rotas("servicos", crud(prisma.servico, "ser_id"), servicoSchema);
rotas("pecas", crud(prisma.peca, "pec_id"), pecaSchema);
rotas("ordens", crud(prisma.ordem, "ord_id", { cliente: true, veiculo: true }), ordemSchema);

export { router };
