import { Request, Response } from "express";
import { ErroApi } from "../middlewares/erros";

export function crud(model: any, pk: string, include?: object) {

    const pegarId = (req: Request) => {
        const id = Number(req.params.id)
        if (!Number.isInteger(id)) throw new ErroApi("Id inválido!")
        return id
    }

    return {
        listar: async (_req: Request, res: Response) => {
            res.json(await model.findMany({ include, orderBy: { [pk]: "asc" } }))
        },

        buscar: async (req: Request, res: Response) => {
            const item = await model.findUnique({ where: { [pk]: pegarId(req) }, include })
            if (!item) throw new ErroApi("Registro não encontrado!", 404)
            res.json(item)
        },

        criar: async (req: Request, res: Response) => {
            res.status(201).json(await model.create({ data: req.body, include }))
        },

        atualizar: async (req: Request, res: Response) => {
            res.json(await model.update({ where: { [pk]: pegarId(req) }, data: req.body, include }))
        },

        excluir: async (req: Request, res: Response) => {
            await model.delete({ where: { [pk]: pegarId(req) } })
            res.json({ mensagem: "Registro excluído!" })
        },
    }
}
