import { Request, Response } from "express";
import { compare, hash } from "bcryptjs";
import prisma from "../prisma";
import { ErroApi } from "../middlewares/erros";

const select = {
    user_id: true,
    user_name: true,
    user_email: true,
    user_status: true,
    user_type: true,
    createAt: true,
}

export async function listar(_req: Request, res: Response) {
    res.json(await prisma.user.findMany({ select }))
}

export async function buscar(req: Request, res: Response) {
    const user = await prisma.user.findUnique({ where: { user_id: Number(req.params.id) }, select })
    if (!user) throw new ErroApi("Usuário não encontrado!", 404)
    res.json(user)
}

export async function criar(req: Request, res: Response) {
    const { user_password, ...dados } = req.body

    const existe = await prisma.user.findUnique({ where: { user_email: dados.user_email } })
    if (existe) throw new ErroApi("Usuário já está cadastrado!", 409)

    const user = await prisma.user.create({
        data: { ...dados, user_password: await hash(user_password, 8) },
        select,
    })
    res.status(201).json(user)
}

export async function atualizar(req: Request, res: Response) {
    const { user_password, ...dados } = req.body

    if (user_password) dados.user_password = await hash(user_password, 8)

    const user = await prisma.user.update({
        where: { user_id: Number(req.params.id) },
        data: dados,
        select,
    })
    res.json(user)
}

export async function excluir(req: Request, res: Response) {
    await prisma.user.delete({ where: { user_id: Number(req.params.id) } })
    res.json({ mensagem: "Usuário excluído!" })
}

export async function login(req: Request, res: Response) {
    const { user_email, user_password } = req.body

    const user = await prisma.user.findUnique({ where: { user_email } })
    if (!user) throw new ErroApi("E-mail ou senha incorretos.", 401)

    const { user_password: senhaSalva, ...dados } = user

    if (!(await compare(user_password, senhaSalva))) {
        throw new ErroApi("E-mail ou senha incorretos.", 401)
    }
    if (dados.user_status === "inativo") {
        throw new ErroApi("Usuário inativo.", 403)
    }

    res.json(dados)
}
