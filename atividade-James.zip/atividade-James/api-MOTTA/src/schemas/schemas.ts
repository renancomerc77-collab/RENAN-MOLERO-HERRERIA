import { z } from 'zod'

export const loginSchema = z.object({
    body: z.object({
        user_email: z.email({message: "Informe um e-mail válido!"}),
        user_password: z.string({message: "Informe a senha!"}),
    })
})

const user = {
    user_name: z.string({message: "O nome deve ser um texto!"})
        .min(3, {message: "O nome deve ter no minimo 3 caracteres!"}),

    user_email: z.email({message: "Informe um e-mail válido!"}),

    user_password: z.string({message: "Você deve informar uma senha!"})
        .min(6, {message: "A senha deve possuir pelo menos 6 caracteres!"}),

    user_status: z.enum(["ativo", "inativo"],
        {message: "O status deve ser ativo ou inativo!"}).optional(),

    user_type: z.enum(["admin", "user", "cliente"],
        {message: "O tipo deve ser admin, user ou cliente!"}).optional(),
}

export const createUserSchema = z.object({
    body: z.object(user)
})

export const updateUserSchema = z.object({
    body: z.object(user).partial()
})

export const clienteSchema = z.object({
    body: z.object({
        cli_nome: z.string({message: "Informe o nome!"})
            .min(3, {message: "O nome deve ter no minimo 3 caracteres!"}),
        cli_email: z.email({message: "Informe um e-mail válido!"}),
        cli_telefone: z.string({message: "Informe o telefone!"})
            .min(8, {message: "Telefone inválido!"}),
        cli_cidade: z.string({message: "Informe a cidade!"})
            .min(2, {message: "Informe a cidade!"}),
    })
})

export const veiculoSchema = z.object({
    body: z.object({
        vei_marca: z.string({message: "Informe a marca!"})
            .min(2, {message: "Informe a marca!"}),
        vei_modelo: z.string({message: "Informe o modelo!"})
            .min(1, {message: "Informe o modelo!"}),
        vei_ano: z.coerce.number({message: "O ano deve ser um número!"})
            .int({message: "O ano deve ser um número inteiro!"})
            .min(1950, {message: "Ano inválido!"})
            .max(2100, {message: "Ano inválido!"}),
        vei_placa: z.string({message: "Informe a placa!"})
            .min(7, {message: "A placa deve ter pelo menos 7 caracteres!"}),
    })
})

export const servicoSchema = z.object({
    body: z.object({
        ser_descricao: z.string({message: "Informe a descrição!"})
            .min(3, {message: "A descrição deve ter no minimo 3 caracteres!"}),
        ser_valor: z.coerce.number({message: "O valor deve ser um número!"})
            .min(0, {message: "O valor não pode ser negativo!"}),
        ser_duracao: z.string({message: "Informe a duração!"})
            .min(1, {message: "Informe a duração!"}),
        ser_observacao: z.string().max(500, {message: "Observação muito grande!"}).optional(),
    })
})

export const pecaSchema = z.object({
    body: z.object({
        pec_nome: z.string({message: "Informe o nome!"})
            .min(2, {message: "O nome deve ter no minimo 2 caracteres!"}),
        pec_numeracao: z.string({message: "Informe a numeração!"})
            .min(1, {message: "Informe a numeração!"}),
        pec_categoria: z.enum(
            ["Filtros", "Freios", "Suspensão", "Pneus", "Elétrica", "Motor", "Óleos", "Mangueiras", "Outros"],
            {message: "Categoria inválida!"}),
        pec_preco: z.coerce.number({message: "O preço deve ser um número!"})
            .min(0, {message: "O preço não pode ser negativo!"}),
        pec_quantidade: z.coerce.number({message: "A quantidade deve ser um número!"})
            .int({message: "A quantidade deve ser um número inteiro!"})
            .min(0, {message: "A quantidade não pode ser negativa!"}),
    })
})

export const ordemSchema = z.object({
    body: z.object({
        cli_id: z.coerce.number({message: "Informe o cliente!"}).int(),
        vei_id: z.coerce.number({message: "Informe o veículo!"}).int(),
        ord_status: z.enum(["Aberto", "Em andamento", "Concluído", "Cancelado"],
            {message: "Status inválido!"}),
        ord_data: z.coerce.date({message: "Informe uma data válida!"}),
    })
})
